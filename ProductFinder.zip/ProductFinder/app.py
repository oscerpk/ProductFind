from flask import Flask, render_template, request
import pandas as pd

from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.common.by import By
from selenium.webdriver.support.wait import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium import webdriver
from selenium.webdriver.chrome.service import Service as ChromeService
from webdriver_manager.chrome import ChromeDriverManager
import pandas as pd
import time
import pdb
import pandas as pd
from ebaysdk.finding import Connection as Finding
from ebaysdk.exception import ConnectionError
from IPython.display import HTML
# pdb.set_trace() 

app = Flask(__name__)




    
def filter_product(name, specific=''):
    global df
    if not df.empty:
        # Convert both DataFrame column and search terms to lowercase for case-insensitive matching
        name_lower = name.lower()
        specific_lower = specific.lower()

        # Filter DataFrame based on whether column "Product" matches 'name' or 'specific'
        cond = df["Product"].str.lower().str.contains(name_lower, na=False) & df["Product"].str.lower().str.contains(specific_lower, na=False)
        df = df[cond]
        return df
    else:
        return df


def rocket_it(keyword, CN='US'):
    try:
        api = Finding(appid='UsmanSha-FindProd-PRD-2e5a98e2e-30780548',
                      certid='PRD-e5a98e2ec506-c4dc-4a35-8400-e24f',
                      devid='756dee3e-0997-404c-975a-5bfd36b1afc1',
                      config_file=None,
                      domain='svcs.ebay.com')  # Production domain

        df = pd.DataFrame(columns=['Product', 'Price', 'URL', 'Location', 'Image URL'])

        processed_item_ids = set()
        item_filters = [
            {'name': 'AvailableTo', 'value': CN},
            {'name': 'LocatedIn', 'value': 'US'},
        ]

        response = api.execute('findItemsAdvanced', {'keywords': keyword, 'itemFilter': item_filters})
        pages = response.reply.paginationOutput.totalPages
        pages = int(pages)

        for page in range(1, pages + 1):
            response = api.execute('findItemsAdvanced', {'keywords': keyword, 'paginationInput.pageNumber': page, 'itemFilter': item_filters})
            items = response.reply.searchResult.item

            for item in items:
                item_id = item.itemId
                if item_id not in processed_item_ids and item.location and "USA" in item.location.upper():
                    processed_item_ids.add(item_id)
                    ship_to = item.shippingInfo.shipToLocations if item.shippingInfo.shipToLocations else "No shipping"
                    image_url = item.galleryURL if item.galleryURL else "No Image Available"
                    price = item.sellingStatus.currentPrice.value + ' ' + item.sellingStatus.currentPrice._currencyId
                    df = df.append({'Product': item.title,
                                    'Price': price,
                                    'URL': item.viewItemURL,
                                    'Location': item.location,
                                    'Image URL': image_url,
                                    'Ships To': ship_to
                                    },
                                   ignore_index=True)

        def display_image(image_src):
            return f'<img src="{image_src}" width="100" />'

        df['Image'] = df['Image URL'].apply(display_image)

        def make_clickable(url):
            return f'<a href="{url}" target="_blank">Link</a>'

        df['URL'] = df['URL'].apply(make_clickable)

        # Drop the original 'Image URL' column
        df = df.drop('Image URL', axis=1)

        return df

    except ConnectionError as e:
        print(e)
        print(e.response.dict())
        return pd.DataFrame()  # Return an empty DataFrame in case of an error




df = pd.DataFrame()

@app.route('/', methods=['GET', 'POST'])
def rocket():
    global df
    output_html = ''
    if request.method == 'POST':
        product_name = request.form['product_name']
        Cn = request.form.get('CN')
        if 'search' in request.form:
            df = rocket_it(product_name,Cn)
        elif 'filter' in request.form:
            df=filter_product(product_name)
        elif 'save' in request.form:
            df.to_csv('latest.csv')
        elif 'open' in request.form:
            df=pd.read_csv('latest.csv')
        output_html = df.to_html(index=False, escape=False)
            

    return render_template('glow.html', output=output_html)



if __name__ == '__main__':
    app.run(debug=True)


